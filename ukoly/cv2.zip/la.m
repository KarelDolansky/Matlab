function ave = la(x)
 ave = (sin(x).^2).*(cos(x));
end