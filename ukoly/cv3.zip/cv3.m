B = round(randn(5,10));
% B =[1,2,7,1;
%      1,6,1,2;
%      3,2,1,5];

disp('vstupní pole')
B

B_sorted = VecBubbleSort(B);
disp('seřazené pole')
B_sorted

